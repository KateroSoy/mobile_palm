import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Block, Harvest, Task, Fertilizer, InventoryItem, Expense, Sale } from '../types';

interface AppState {
  blocks: Block[];
  harvests: Harvest[];
  tasks: Task[];
  fertilizers: Fertilizer[];
  inventory: InventoryItem[];
  expenses: Expense[];
  sales: Sale[];
}

interface AppContextType extends AppState {
  addHarvest: (harvest: Omit<Harvest, 'id'>) => void;
  updateHarvest: (id: string, harvest: Omit<Harvest, 'id'>) => void;
  deleteHarvest: (id: string) => void;
  
  updateTaskStatus: (id: string, status: Task['status']) => void;
}

const initialState: AppState = {
  blocks: [
    { id: 'b1', name: 'Blok A01', divisi: 'Divisi 1', kebun: 'Kebun Sungai Hijau', luasHa: 25, tahunTanam: 2015, jumlahPohon: 3400, produksiTon: 450, terakhirDipupuk: '2023-10-15' },
    { id: 'b2', name: 'Blok A02', divisi: 'Divisi 1', kebun: 'Kebun Sungai Hijau', luasHa: 30, tahunTanam: 2016, jumlahPohon: 4050, produksiTon: 520, terakhirDipupuk: '2023-11-02' },
    { id: 'b3', name: 'Blok A03', divisi: 'Divisi 1', kebun: 'Kebun Sungai Hijau', luasHa: 28, tahunTanam: 2015, jumlahPohon: 3780, produksiTon: 490, terakhirDipupuk: '2023-09-20' },
    { id: 'b4', name: 'Blok B01', divisi: 'Divisi 2', kebun: 'Kebun Sungai Hijau', luasHa: 35, tahunTanam: 2018, jumlahPohon: 4800, produksiTon: 600, terakhirDipupuk: '2023-12-05' },
    { id: 'b5', name: 'Blok B02', divisi: 'Divisi 2', kebun: 'Kebun Sungai Hijau', luasHa: 32, tahunTanam: 2018, jumlahPohon: 4350, produksiTon: 550, terakhirDipupuk: '2023-12-10' },
    { id: 'b6', name: 'Blok B03', divisi: 'Divisi 2', kebun: 'Kebun Sungai Hijau', luasHa: 40, tahunTanam: 2019, jumlahPohon: 5400, produksiTon: 680, terakhirDipupuk: '2024-01-15' },
  ],
  harvests: [
    { id: 'h1', tanggal: '2024-02-20', blokId: 'b1', mandor: 'Supriyanto', pekerja: 'Tim A (5 org)', jumlahJanjang: 450, beratTBSKg: 9500, looseFruitKg: 150, kualitas: 'Baik', catatan: 'Panen lancar' },
    { id: 'h2', tanggal: '2024-02-21', blokId: 'b2', mandor: 'Heri', pekerja: 'Tim B (4 org)', jumlahJanjang: 380, beratTBSKg: 7800, looseFruitKg: 100, kualitas: 'Sedang', catatan: 'Sebagian buah menginap' },
  ],
  tasks: [
    { id: 't1', kategori: 'PANEN', blokId: 'b1', target: '450 janjang', status: 'Selesai', tanggal: '2024-02-22' },
    { id: 't2', kategori: 'PEMUPUKAN', blokId: 'b4', target: '18 Ha', status: 'Berjalan', tanggal: '2024-02-22' },
    { id: 't3', kategori: 'PERAWATAN', blokId: 'b3', target: 'Bersihkan piringan', status: 'Belum Mulai', tanggal: '2024-02-22' },
  ],
  fertilizers: [
    { id: 'f1', blokId: 'b1', jenisPupuk: 'NPK', dosisPerPohonKg: 2.5, tanggalAplikasi: '2024-02-10', status: 'Selesai' },
    { id: 'f2', blokId: 'b4', jenisPupuk: 'Urea', dosisPerPohonKg: 1.5, tanggalAplikasi: '2024-02-22', status: 'Berjalan' },
  ],
  inventory: [
    { id: 'i1', nama: 'NPK', stok: 850, satuan: 'Kg', minimumStok: 1000 },
    { id: 'i2', nama: 'Urea', stok: 2500, satuan: 'Kg', minimumStok: 1500 },
    { id: 'i3', nama: 'KCl', stok: 1200, satuan: 'Kg', minimumStok: 1000 },
    { id: 'i4', nama: 'Dolomite', stok: 5000, satuan: 'Kg', minimumStok: 2000 },
    { id: 'i5', nama: 'Herbisida', stok: 45, satuan: 'Liter', minimumStok: 50 },
    { id: 'i6', nama: 'Solar', stok: 1500, satuan: 'Liter', minimumStok: 500 },
  ],
  expenses: [
    { id: 'e1', tanggal: '2024-02-15', kategori: 'Tenaga Kerja', lokasi: 'Kebun Sungai Hijau', nominal: 15000000, keterangan: 'Gaji BHL periode 1' },
    { id: 'e2', tanggal: '2024-02-18', kategori: 'BBM', lokasi: 'Gudang Pusat', nominal: 3500000, keterangan: 'Pembelian Solar 500L' },
  ],
  sales: [
    { id: 's1', tanggal: '2024-02-19', buyer: 'PKS Makmur Jaya', beratBersihKg: 15400, hargaPerKg: 3125 },
    { id: 's2', tanggal: '2024-02-21', buyer: 'PKS Nusantara', beratBersihKg: 22100, hargaPerKg: 3150 },
  ]
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(initialState);

  const addHarvest = (harvest: Omit<Harvest, 'id'>) => {
    setState(prev => ({
      ...prev,
      harvests: [...prev.harvests, { ...harvest, id: Math.random().toString(36).substr(2, 9) }]
    }));
  };

  const updateHarvest = (id: string, harvest: Omit<Harvest, 'id'>) => {
    setState(prev => ({
      ...prev,
      harvests: prev.harvests.map(h => h.id === id ? { ...harvest, id } : h)
    }));
  };

  const deleteHarvest = (id: string) => {
    setState(prev => ({
      ...prev,
      harvests: prev.harvests.filter(h => h.id !== id)
    }));
  };

  const updateTaskStatus = (id: string, status: Task['status']) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => t.id === id ? { ...t, status } : t)
    }));
  };

  return (
    <AppContext.Provider value={{ ...state, addHarvest, updateHarvest, deleteHarvest, updateTaskStatus }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
