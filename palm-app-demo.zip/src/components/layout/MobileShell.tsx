import React from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Home, ClipboardList, Map, User, ScanLine } from 'lucide-react';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

const navItems = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'Aktivitas', path: '/aktivitas', icon: ClipboardList },
  { name: 'Panen', path: '/panen', icon: ScanLine, isCenter: true },
  { name: 'Kebun', path: '/kebun', icon: Map },
  { name: 'Profil', path: '/profil', icon: User },
];

export function MobileShell() {
  const location = useLocation();
  const hideNavPaths = ['/panen/scan']; // Hide bottom nav on specific screens
  const showNav = !hideNavPaths.some(p => location.pathname.includes(p));

  return (
    <div className="flex justify-center bg-gray-100 min-h-screen">
      <div className="w-full max-w-[430px] bg-bg-main h-screen md:h-[90vh] md:my-auto md:rounded-[40px] md:shadow-2xl overflow-hidden relative flex flex-col shadow-soft border-x md:border-y border-gray-200">
        
        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden hide-scrollbar pb-32">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="min-h-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Floating Bottom Navigation */}
        <AnimatePresence>
          {showNav && (
            <motion.div 
              initial={{ y: 100 }}
              animate={{ y: 0 }}
              exit={{ y: 100 }}
              className="absolute bottom-6 inset-x-6 z-50 pointer-events-none"
            >
              <div className="bg-surface rounded-full shadow-float px-6 py-4 flex items-center justify-between pointer-events-auto border border-gray-100/50">
                {navItems.map((item) => {
                  const isActive = location.pathname === item.path;
                  const Icon = item.icon;

                  if (item.isCenter) {
                    return (
                      <NavLink
                        key={item.name}
                        to={item.path}
                        className="relative -top-6 bg-palm text-white w-16 h-16 rounded-full flex items-center justify-center shadow-float shrink-0 active:scale-95 transition-transform"
                      >
                        <Icon className="w-7 h-7" strokeWidth={2.5} />
                      </NavLink>
                    );
                  }

                  return (
                    <NavLink
                      key={item.name}
                      to={item.path}
                      className={cn(
                        "flex flex-col items-center gap-1 transition-colors relative",
                        isActive ? "text-palm-dark" : "text-text-sec hover:text-text-main"
                      )}
                    >
                      <Icon className="w-6 h-6" strokeWidth={isActive ? 2.5 : 2} />
                      {isActive && (
                        <motion.div 
                          layoutId="nav-indicator"
                          className="w-1.5 h-1.5 rounded-full bg-palm absolute -bottom-3"
                        />
                      )}
                    </NavLink>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
