import React from 'react';
import { useAppContext } from '../store/AppContext';
import { FlaskConical } from 'lucide-react';

export function Pemupukan() {
  const { fertilizers, blocks } = useAppContext();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Pemupukan</h1>
          <p className="text-sm text-gray-500">Jadwal dan realisasi aplikasi pupuk</p>
        </div>
        <button className="inline-flex items-center justify-center px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors">
          Buat Jadwal
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {fertilizers.map(fert => {
          const block = blocks.find(b => b.id === fert.blokId);
          const totalKebutuhan = block ? (block.jumlahPohon * fert.dosisPerPohonKg) : 0;

          return (
            <div key={fert.id} className="bg-white border border-gray-200 rounded-xl shadow-sm p-5">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                    <FlaskConical className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{fert.jenisPupuk}</h3>
                    <p className="text-xs text-gray-500">Aplikasi: {new Date(fert.tanggalAplikasi).toLocaleDateString('id-ID')}</p>
                  </div>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded-md ${
                  fert.status === 'Selesai' ? 'bg-emerald-100 text-emerald-700' :
                  fert.status === 'Berjalan' ? 'bg-blue-100 text-blue-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {fert.status}
                </span>
              </div>

              <div className="mt-4 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Lokasi Blok</span>
                  <span className="font-medium text-gray-900">{block?.name}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Dosis per Pohon</span>
                  <span className="font-medium text-gray-900">{fert.dosisPerPohonKg} Kg</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Jumlah Pohon</span>
                  <span className="font-medium text-gray-900">{block?.jumlahPohon.toLocaleString()}</span>
                </div>
                <div className="pt-3 border-t border-gray-100 flex justify-between text-sm">
                  <span className="font-medium text-gray-700">Total Kebutuhan</span>
                  <span className="font-bold text-emerald-600">{totalKebutuhan.toLocaleString()} Kg</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
