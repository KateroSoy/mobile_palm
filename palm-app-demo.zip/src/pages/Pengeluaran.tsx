import React from 'react';
import { useAppContext } from '../store/AppContext';
import { Plus, Receipt } from 'lucide-react';

export function Pengeluaran() {
  const { expenses } = useAppContext();

  const totalPengeluaran = expenses.reduce((acc, curr) => acc + curr.nominal, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Pengeluaran</h1>
          <p className="text-sm text-gray-500">Pencatatan biaya operasional kebun</p>
        </div>
        <button className="inline-flex items-center justify-center px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors">
          <Plus className="w-4 h-4 mr-2" />
          Catat Pengeluaran
        </button>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-5 mb-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-red-50 text-red-600 rounded-xl">
            <Receipt className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500 mb-1">Total Pengeluaran (Bulan Ini)</p>
            <h2 className="text-3xl font-bold text-gray-900">
              Rp {totalPengeluaran.toLocaleString('id-ID')}
            </h2>
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-600">
            <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-5 py-3 font-medium">Tanggal</th>
                <th className="px-5 py-3 font-medium">Kategori</th>
                <th className="px-5 py-3 font-medium">Keterangan</th>
                <th className="px-5 py-3 font-medium">Lokasi</th>
                <th className="px-5 py-3 font-medium text-right">Nominal (Rp)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {expenses.map((expense) => (
                <tr key={expense.id} className="hover:bg-gray-50">
                  <td className="px-5 py-4 whitespace-nowrap">{new Date(expense.tanggal).toLocaleDateString('id-ID')}</td>
                  <td className="px-5 py-4">
                    <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-700">
                      {expense.kategori}
                    </span>
                  </td>
                  <td className="px-5 py-4">{expense.keterangan}</td>
                  <td className="px-5 py-4">{expense.lokasi}</td>
                  <td className="px-5 py-4 text-right font-medium text-gray-900">
                    {expense.nominal.toLocaleString('id-ID')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
