import React from 'react';
import { useAppContext } from '../store/AppContext';
import { Bell, ArrowUpRight, TrendingUp, CheckCircle2, ChevronRight, Droplets } from 'lucide-react';

export function Dashboard() {
  const { blocks, tasks } = useAppContext();

  return (
    <div className="pb-12">
      {/* Header */}
      <div className="px-6 pt-12 pb-4 flex justify-between items-start">
        <div>
          <h1 className="text-[26px] font-bold text-text-main leading-tight">
            Selamat pagi,<br />Jack Ma
          </h1>
          <p className="text-[13px] text-text-sec mt-1.5 font-medium">
            Kebun Sungai Hijau • 25 Agustus 2026
          </p>
        </div>
        <button className="w-12 h-12 bg-surface rounded-full flex items-center justify-center shadow-float border border-gray-100/50 relative">
          <Bell className="w-5 h-5 text-text-main" />
          <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-palm border-2 border-white rounded-full"></span>
        </button>
      </div>

      {/* Hero Plantation Card */}
      <div className="px-6 mt-4">
        <div className="relative w-full h-[180px] rounded-[28px] overflow-hidden shadow-soft">
          <img 
            src="https://images.unsplash.com/photo-1621508620775-520f30504d60?auto=format&fit=crop&q=80&w=800&h=400" 
            alt="Plantation" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
          <div className="absolute bottom-5 left-5 right-5 flex justify-between items-end">
            <div>
              <h2 className="text-white text-[20px] font-bold">Kebun Sungai Hijau</h2>
              <p className="text-white/80 text-[13px] font-medium mt-0.5">850 Ha • 6 Divisi • 48 Blok</p>
            </div>
            <div className="bg-palm/90 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-white rounded-full"></span>
              <span className="text-white text-[11px] font-bold tracking-wide">BAIK</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Category Pills */}
      <div className="mt-8 px-6 flex gap-3 overflow-x-auto hide-scrollbar pb-2">
        <Pill label="Semua" active />
        <Pill label="Panen" />
        <Pill label="Pupuk" />
        <Pill label="Perawatan" />
        <Pill label="Hama" />
      </div>

      {/* Horizontal KPI Cards */}
      <div className="mt-4 px-6 flex gap-4 overflow-x-auto hide-scrollbar pb-4 snap-x">
        <div className="snap-start shrink-0 w-[140px] bg-surface rounded-[22px] p-4 shadow-soft">
          <h3 className="text-[28px] font-bold text-text-main leading-none">42,8</h3>
          <p className="text-[11px] font-bold text-text-sec mt-1 uppercase tracking-wider">TON</p>
          <p className="text-[13px] font-medium text-text-main mt-4">Panen Hari Ini</p>
          <div className="flex items-center gap-1 text-palm text-[12px] font-bold mt-1">
            <ArrowUpRight className="w-3.5 h-3.5" /> 8,4%
          </div>
        </div>

        <div className="snap-start shrink-0 w-[140px] bg-surface rounded-[22px] p-4 shadow-soft">
          <h3 className="text-[28px] font-bold text-text-main leading-none">95<span className="text-[18px]">%</span></h3>
          <p className="text-[11px] font-bold text-text-sec mt-1 uppercase tracking-wider">Tercapai</p>
          <p className="text-[13px] font-medium text-text-main mt-4">Target Hari Ini</p>
          <div className="flex items-center gap-1 text-text-sec text-[12px] font-medium mt-1">
            Sisa 2,2 Ton
          </div>
        </div>

        <div className="snap-start shrink-0 w-[140px] bg-surface rounded-[22px] p-4 shadow-soft">
          <h3 className="text-[28px] font-bold text-text-main leading-none">1,82</h3>
          <p className="text-[11px] font-bold text-text-sec mt-1 uppercase tracking-wider">Ton / Ha</p>
          <p className="text-[13px] font-medium text-text-main mt-4">Yield Bulan Ini</p>
          <div className="flex items-center gap-1 text-palm text-[12px] font-bold mt-1">
            <ArrowUpRight className="w-3.5 h-3.5" /> 2,1%
          </div>
        </div>
      </div>

      {/* Hero Production Card */}
      <div className="px-6 mt-4">
        <div className="bg-surface rounded-[28px] p-6 shadow-soft flex items-center justify-between">
          <div>
            <p className="text-[13px] font-semibold text-text-sec mb-1">Produksi Bulan Ini</p>
            <h3 className="text-[32px] font-bold text-text-main leading-none">1.284 <span className="text-[16px] text-text-sec">Ton</span></h3>
            <p className="text-[13px] font-medium text-text-sec mt-3">Target: 1.350 Ton</p>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-palm/10 text-palm rounded-full text-[12px] font-bold mt-3">
              <TrendingUp className="w-3.5 h-3.5" /> +7,2% vs Lalu
            </div>
          </div>
          <div className="relative w-[100px] h-[100px] flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="50" cy="50" r="45" stroke="#F0F1ED" strokeWidth="8" fill="none" />
              <circle cx="50" cy="50" r="45" stroke="#4CC356" strokeWidth="8" fill="none" strokeDasharray="283" strokeDashoffset="283" className="animate-[dash_1.5s_ease-out_forwards]" style={{strokeDashoffset: 283 - (283 * 0.95)}} strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-[20px] font-bold text-text-main">95%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Plantation Activity Cards */}
      <div className="px-6 mt-8 mb-4 flex justify-between items-end">
        <h2 className="text-[20px] font-bold text-text-main">Aktivitas Berjalan</h2>
        <button className="text-[13px] font-bold text-palm flex items-center">
          Lihat Semua <ChevronRight className="w-4 h-4 ml-0.5" />
        </button>
      </div>

      <div className="px-6 space-y-4">
        <ActivityCard 
          image="https://images.unsplash.com/photo-1601055531551-789ecce21731?auto=format&fit=crop&q=80&w=150&h=150"
          title="Panen"
          location="Blok A12"
          meta="450 Janjang • 12 Pekerja"
          progress={69}
        />
        <ActivityCard 
          image="https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&q=80&w=150&h=150"
          title="Pemupukan"
          location="Blok B04"
          meta="18 Ha • NPK"
          progress={30}
          icon={Droplets}
        />
      </div>

    </div>
  );
}

function Pill({ label, active }: { label: string, active?: boolean }) {
  return (
    <button className={`shrink-0 px-5 py-2.5 rounded-full text-[14px] font-semibold transition-colors ${
      active ? 'bg-palm text-white shadow-md shadow-palm/20' : 'bg-surface-sec text-text-sec'
    }`}>
      {label}
    </button>
  );
}

function ActivityCard({ image, title, location, meta, progress, icon: Icon }: any) {
  return (
    <div className="bg-surface rounded-[22px] p-3 shadow-soft flex items-center gap-4 active:scale-[0.98] transition-transform">
      <div className="w-[68px] h-[68px] rounded-[16px] overflow-hidden shrink-0 relative">
        <img src={image} alt={title} className="w-full h-full object-cover" />
        {Icon && (
          <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
             <Icon className="w-6 h-6 text-white" />
          </div>
        )}
      </div>
      <div className="flex-1">
        <h4 className="text-[16px] font-bold text-text-main">{title}</h4>
        <p className="text-[13px] font-medium text-text-main mt-0.5">{location}</p>
        <p className="text-[12px] text-text-sec mt-1">{meta}</p>
      </div>
      <div className="pr-2">
        <div className="relative w-12 h-12 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90">
            <circle cx="24" cy="24" r="20" stroke="#F0F1ED" strokeWidth="4" fill="none" />
            <circle cx="24" cy="24" r="20" stroke="#4CC356" strokeWidth="4" fill="none" strokeDasharray="125" strokeDashoffset={125 - (125 * (progress/100))} strokeLinecap="round" />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            {progress === 100 ? (
              <CheckCircle2 className="w-5 h-5 text-palm" />
            ) : (
              <span className="text-[10px] font-bold text-text-main">{progress}%</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

