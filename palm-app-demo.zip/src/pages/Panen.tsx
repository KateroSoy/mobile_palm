import React, { useState } from 'react';
import { useAppContext } from '../store/AppContext';
import { Plus, Camera, X, ArrowRight, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

export function Panen() {
  const { harvests, blocks, addHarvest } = useAppContext();
  const [isScanning, setIsScanning] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const [formData, setFormData] = useState({
    tanggal: format(new Date(), 'yyyy-MM-dd'),
    blokId: blocks.find(b => b.name === 'Blok A12')?.id || blocks[0]?.id,
    mandor: 'Pak Budi',
    pekerja: 'Tim Panen 1',
    jumlahJanjang: '',
    beratTBSKg: '',
    looseFruitKg: '',
    kualitas: 'Matang',
    catatan: ''
  });

  const bjr = formData.jumlahJanjang && formData.beratTBSKg 
    ? (Number(formData.beratTBSKg) / Number(formData.jumlahJanjang)).toFixed(2)
    : '0.00';

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    addHarvest({
      ...formData,
      jumlahJanjang: Number(formData.jumlahJanjang),
      beratTBSKg: Number(formData.beratTBSKg),
      looseFruitKg: Number(formData.looseFruitKg),
    });
    
    setIsFormOpen(false);
    setIsScanning(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
    
    // Reset form
    setFormData({
      ...formData,
      jumlahJanjang: '',
      beratTBSKg: '',
      looseFruitKg: '',
    });
  };

  return (
    <div className="pb-12 relative h-full">
      {/* List View */}
      <div className="px-6 pt-12 pb-4 flex justify-between items-center">
        <h1 className="text-[26px] font-bold text-text-main">Panen</h1>
        <button 
          onClick={() => setIsScanning(true)}
          className="w-10 h-10 bg-palm text-white rounded-full flex items-center justify-center shadow-md active:scale-95 transition-transform"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="px-6 mt-2">
        <div className="relative w-full h-[220px] rounded-[28px] overflow-hidden shadow-soft">
          <img 
            src="https://images.unsplash.com/photo-1601055531551-789ecce21731?auto=format&fit=crop&q=80&w=800" 
            alt="Harvest" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute bottom-5 left-5 right-5">
            <p className="text-white/80 text-[13px] font-medium mb-1">Hari Ini</p>
            <h2 className="text-white text-[28px] font-bold leading-none">42,8 Ton</h2>
            <p className="text-white/90 text-[15px] font-medium mt-1">1.984 Janjang</p>
          </div>
        </div>

        <div className="flex gap-3 mt-4">
          <div className="flex-1 bg-surface rounded-[20px] p-4 shadow-soft">
            <h3 className="text-[20px] font-bold text-text-main">21,6 <span className="text-[12px]">Kg</span></h3>
            <p className="text-[11px] font-bold text-text-sec mt-1 uppercase tracking-wider">BJR Rata-rata</p>
          </div>
          <div className="flex-1 bg-surface rounded-[20px] p-4 shadow-soft">
            <h3 className="text-[20px] font-bold text-text-main">8</h3>
            <p className="text-[11px] font-bold text-text-sec mt-1 uppercase tracking-wider">Blok Aktif</p>
          </div>
          <div className="flex-1 bg-surface rounded-[20px] p-4 shadow-soft">
            <h3 className="text-[20px] font-bold text-text-main">42</h3>
            <p className="text-[11px] font-bold text-text-sec mt-1 uppercase tracking-wider">Pemanen</p>
          </div>
        </div>
      </div>

      <div className="px-6 mt-8 space-y-4">
        <h2 className="text-[18px] font-bold text-text-main mb-2">Riwayat Panen</h2>
        {harvests.slice().reverse().map(harvest => {
          const block = blocks.find(b => b.id === harvest.blokId);
          return (
            <div key={harvest.id} className="bg-surface rounded-[24px] p-4 shadow-soft flex items-center justify-between">
              <div>
                <h3 className="text-[16px] font-bold text-text-main">{block?.name}</h3>
                <p className="text-[13px] font-medium text-text-sec mt-0.5">{harvest.jumlahJanjang} Janjang • {harvest.beratTBSKg} Kg</p>
              </div>
              <div className="text-right">
                <p className="text-[14px] font-bold text-palm">{harvest.kualitas}</p>
                <p className="text-[11px] text-text-sec mt-1">{format(new Date(harvest.tanggal), 'dd MMM')}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Success Overlay */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none"
          >
            <div className="bg-black/40 absolute inset-0 backdrop-blur-sm" />
            <motion.div 
              initial={{ scale: 0.8 }} animate={{ scale: 1 }} exit={{ scale: 0.8 }}
              className="bg-white rounded-3xl p-8 flex flex-col items-center shadow-2xl relative z-10"
            >
              <div className="w-20 h-20 bg-palm rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-xl font-bold text-text-main">Berhasil Disimpan</h2>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Scanner View */}
      <AnimatePresence>
        {isScanning && (
          <motion.div 
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 bg-black flex flex-col"
          >
            <div className="relative flex-1">
              <img 
                src="https://images.unsplash.com/photo-1601055531551-789ecce21731?auto=format&fit=crop&q=80&w=600" 
                alt="Scanner view" 
                className="absolute inset-0 w-full h-full object-cover opacity-70"
              />
              <div className="absolute inset-0 bg-black/30" />
              
              {/* Top Bar */}
              <div className="absolute top-0 inset-x-0 p-6 flex justify-between items-center z-10">
                <button onClick={() => setIsScanning(false)} className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white">
                  <X className="w-6 h-6" />
                </button>
                <div className="bg-white/20 backdrop-blur-md px-4 py-2 rounded-full text-white text-[13px] font-semibold">
                  Blok A12
                </div>
              </div>

              {/* Scan Frame */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-[280px] h-[280px] border-2 border-white/30 rounded-[32px] relative">
                  <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-white rounded-tl-[32px]" />
                  <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-white rounded-tr-[32px]" />
                  <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-white rounded-bl-[32px]" />
                  <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-white rounded-br-[32px]" />
                </div>
              </div>
              
              <div className="absolute bottom-32 inset-x-0 text-center">
                <p className="text-white font-medium text-[15px] bg-black/40 px-4 py-2 rounded-full inline-block backdrop-blur-sm">
                  Arahkan kamera ke hasil panen
                </p>
              </div>

              {/* Floating Bottom Card */}
              <div className="absolute bottom-8 inset-x-6 z-10">
                <div className="bg-surface rounded-[28px] p-5 shadow-2xl flex items-center justify-between">
                  <div>
                    <h3 className="text-[18px] font-bold text-text-main">Blok A12</h3>
                    <p className="text-[13px] font-medium text-text-sec mt-0.5">Estimasi 450 Janjang</p>
                  </div>
                  <button 
                    onClick={() => setIsFormOpen(true)}
                    className="w-14 h-14 bg-palm rounded-full flex items-center justify-center shadow-float text-white active:scale-95 transition-transform"
                  >
                    <ArrowRight className="w-6 h-6" strokeWidth={2.5} />
                  </button>
                </div>
              </div>
            </div>
            
            {/* Bottom Sheet Form */}
            <AnimatePresence>
              {isFormOpen && (
                <motion.div
                  initial={{ y: '100%' }}
                  animate={{ y: 0 }}
                  exit={{ y: '100%' }}
                  transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                  className="absolute inset-x-0 bottom-0 bg-surface rounded-t-[34px] z-20 flex flex-col max-h-[90vh]"
                >
                  <div className="p-4 flex justify-center shrink-0">
                    <div className="w-12 h-1.5 bg-gray-200 rounded-full" />
                  </div>
                  
                  <div className="px-6 pb-4 shrink-0 flex justify-between items-center">
                    <h2 className="text-[22px] font-bold text-text-main">Data Panen</h2>
                    <button onClick={() => setIsFormOpen(false)} className="w-8 h-8 bg-surface-sec rounded-full flex items-center justify-center">
                      <X className="w-5 h-5 text-text-sec" />
                    </button>
                  </div>

                  <div className="px-6 overflow-y-auto hide-scrollbar pb-24">
                    <form id="harvest-form" onSubmit={handleSave} className="space-y-5">
                      <div className="bg-surface-sec rounded-[20px] p-4 flex justify-between items-center">
                        <span className="text-[14px] font-semibold text-text-sec">Blok</span>
                        <span className="text-[16px] font-bold text-text-main">A12</span>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-[13px] font-bold text-text-sec uppercase tracking-wide">Janjang</label>
                          <input 
                            type="number" required
                            value={formData.jumlahJanjang} 
                            onChange={e => setFormData({...formData, jumlahJanjang: e.target.value})}
                            className="w-full bg-surface-sec px-4 py-4 rounded-[18px] text-[20px] font-bold text-text-main outline-none focus:ring-2 ring-palm/30"
                            placeholder="0"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[13px] font-bold text-text-sec uppercase tracking-wide">Berat (Kg)</label>
                          <input 
                            type="number" required
                            value={formData.beratTBSKg} 
                            onChange={e => setFormData({...formData, beratTBSKg: e.target.value})}
                            className="w-full bg-surface-sec px-4 py-4 rounded-[18px] text-[20px] font-bold text-text-main outline-none focus:ring-2 ring-palm/30"
                            placeholder="0"
                          />
                        </div>
                      </div>

                      <div className="bg-palm/10 rounded-[20px] p-4 flex justify-between items-center">
                        <span className="text-[14px] font-semibold text-palm-dark">Estimasi BJR</span>
                        <span className="text-[20px] font-bold text-palm">{bjr} Kg</span>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[13px] font-bold text-text-sec uppercase tracking-wide">Kualitas</label>
                        <div className="flex gap-2 overflow-x-auto hide-scrollbar">
                          {['Matang', 'Mengkal', 'Mentah', 'Lewat'].map(qual => (
                            <button
                              key={qual}
                              type="button"
                              onClick={() => setFormData({...formData, kualitas: qual})}
                              className={`shrink-0 px-5 py-3 rounded-full text-[14px] font-semibold transition-colors ${
                                formData.kualitas === qual ? 'bg-palm text-white' : 'bg-surface-sec text-text-sec'
                              }`}
                            >
                              {qual}
                            </button>
                          ))}
                        </div>
                      </div>
                    </form>
                  </div>
                  
                  <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-white via-white to-transparent">
                    <button 
                      type="submit" 
                      form="harvest-form"
                      className="w-full bg-palm text-white py-4 rounded-full text-[16px] font-bold shadow-float active:scale-95 transition-transform"
                    >
                      Simpan Panen
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
