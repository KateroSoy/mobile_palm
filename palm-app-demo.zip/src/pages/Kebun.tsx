import React from 'react';
import { useAppContext } from '../store/AppContext';
import { Search, ChevronRight } from 'lucide-react';

export function Kebun() {
  const { blocks } = useAppContext();

  return (
    <div className="pb-12">
      <div className="px-6 pt-12 pb-4">
        <h1 className="text-[26px] font-bold text-text-main">Kebun</h1>
      </div>

      <div className="px-6">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Cari blok..." 
            className="w-full bg-surface py-3.5 pl-12 pr-4 rounded-[18px] text-[15px] font-medium outline-none shadow-soft placeholder:text-text-sec text-text-main border-2 border-transparent focus:border-palm/20 transition-colors"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-sec" />
        </div>
      </div>

      <div className="mt-6 px-6 flex gap-3 overflow-x-auto hide-scrollbar pb-2">
        <Pill label="Semua" active />
        <Pill label="Produktif" />
        <Pill label="Perlu Panen" />
        <Pill label="Issue" />
      </div>

      <div className="px-6 mt-6 space-y-4">
        {blocks.map(block => (
          <BlockCard key={block.id} block={block} />
        ))}
      </div>
    </div>
  );
}

function Pill({ label, active }: { label: string, active?: boolean }) {
  return (
    <button className={`shrink-0 px-5 py-2.5 rounded-full text-[14px] font-semibold transition-colors ${
      active ? 'bg-palm text-white shadow-md shadow-palm/20' : 'bg-surface-sec text-text-sec'
    }`}>
      {label}
    </button>
  );
}

function BlockCard({ block }: any) {
  const isA12 = block.name === 'Blok A12'; // Highlight this one for demo

  return (
    <div className="bg-surface rounded-[24px] p-3 shadow-soft flex items-center gap-4 active:scale-[0.98] transition-transform">
      <div className="w-[84px] h-[100px] rounded-[18px] overflow-hidden shrink-0">
        <img 
          src={isA12 ? "https://images.unsplash.com/photo-1621508620775-520f30504d60?auto=format&fit=crop&q=80&w=200" : "https://images.unsplash.com/photo-1621508620775-520f30504d60?auto=format&fit=crop&q=80&w=200"} 
          alt={block.name} 
          className="w-full h-full object-cover" 
        />
      </div>
      <div className="flex-1 py-1">
        <h3 className="text-[18px] font-bold text-text-main">{block.name}</h3>
        <p className="text-[13px] text-text-sec font-medium">{block.luasHa} Ha • {block.jumlahPohon} pohon</p>
        
        <div className="mt-3 flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-text-sec uppercase tracking-wider">Yield</p>
            <p className="text-[14px] font-bold text-palm">{(block.produksiTon / block.luasHa).toFixed(2)} T/Ha</p>
          </div>
          {isA12 ? (
            <div className="px-2.5 py-1 bg-red-50 text-red-600 rounded-lg text-[10px] font-bold uppercase tracking-wider">
              Perlu Panen
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full bg-surface-sec flex items-center justify-center text-text-sec">
              <ChevronRight className="w-4 h-4" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
