import React from 'react';
import { useAppContext } from '../store/AppContext';
import { Search, Plus } from 'lucide-react';

export function Gudang() {
  const { inventory } = useAppContext();

  // Helper to get demo images based on item name
  const getImage = (name: string) => {
    if (name.includes('NPK') || name.includes('Urea') || name.includes('KCl') || name.includes('Dolomite')) {
      return "https://images.unsplash.com/photo-1627916568161-55fc3528b18f?auto=format&fit=crop&q=80&w=200"; // Generic bag/fertilizer photo
    }
    if (name.includes('Solar')) {
      return "https://images.unsplash.com/photo-1598444391694-0f1c9fc63ba4?auto=format&fit=crop&q=80&w=200"; // Barrel/Fuel
    }
    return "https://images.unsplash.com/photo-1584984189390-e5dc798151ed?auto=format&fit=crop&q=80&w=200"; // Generic chemical
  };

  return (
    <div className="pb-12">
      <div className="px-6 pt-12 pb-4">
        <h1 className="text-[26px] font-bold text-text-main">Gudang</h1>
      </div>

      <div className="px-6">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Cari stok..." 
            className="w-full bg-surface py-3.5 pl-12 pr-4 rounded-[18px] text-[15px] font-medium outline-none shadow-soft placeholder:text-text-sec text-text-main border-2 border-transparent focus:border-palm/20 transition-colors"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-sec" />
        </div>
      </div>

      <div className="mt-6 px-6 flex gap-3 overflow-x-auto hide-scrollbar pb-2">
        <Pill label="Semua" active />
        <Pill label="Pupuk" />
        <Pill label="Chemical" />
        <Pill label="BBM" />
        <Pill label="Tools" />
        <Pill label="Sparepart" />
      </div>

      <div className="px-6 mt-6 grid grid-cols-2 gap-4">
        {inventory.map(item => {
          const isLowStock = item.stok <= item.minimumStok;
          return (
            <div key={item.id} className="bg-surface rounded-[24px] p-3 shadow-soft flex flex-col active:scale-95 transition-transform">
              <div className="relative w-full h-[120px] rounded-[18px] bg-surface-sec overflow-hidden mb-3 shrink-0">
                <img 
                  src={getImage(item.nama)}
                  alt={item.nama}
                  className="w-full h-full object-cover"
                />
                {isLowStock && (
                  <div className="absolute top-2 left-2 bg-red-500 text-white text-[9px] font-bold px-2 py-1 uppercase tracking-wider rounded-full shadow-sm">
                    Low Stock
                  </div>
                )}
              </div>
              
              <div className="flex-1 flex flex-col">
                <h3 className="text-[14px] font-bold text-text-main leading-tight mb-2 line-clamp-2">{item.nama}</h3>
                
                <div className="mt-auto flex items-end justify-between">
                  <div>
                    <p className={`text-[16px] font-bold ${isLowStock ? 'text-red-500' : 'text-text-main'}`}>
                      {item.stok.toLocaleString()} <span className="text-[11px] font-medium text-text-sec">{item.satuan}</span>
                    </p>
                    <p className="text-[11px] font-medium text-text-sec mt-0.5">
                      Min {item.minimumStok.toLocaleString()}
                    </p>
                  </div>
                  <button className="w-8 h-8 rounded-full bg-palm text-white flex items-center justify-center shadow-float active:scale-90 transition-transform">
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Pill({ label, active }: { label: string, active?: boolean }) {
  return (
    <button className={`shrink-0 px-5 py-2.5 rounded-full text-[14px] font-semibold transition-colors ${
      active ? 'bg-palm text-white shadow-md shadow-palm/20' : 'bg-surface-sec text-text-sec'
    }`}>
      {label}
    </button>
  );
}
