import React from 'react';
import { useAppContext } from '../store/AppContext';
import { CheckCircle2, Circle } from 'lucide-react';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { motion, useAnimation } from 'motion/react';

export function Pekerjaan() {
  const { tasks, blocks, updateTaskStatus } = useAppContext();

  const hariIni = tasks.filter(t => t.tanggal === '2024-02-22'); // demo static date matching
  const selesai = tasks.filter(t => t.status === 'Selesai').length;

  return (
    <div className="pb-12">
      <div className="px-6 pt-12 pb-4">
        <h1 className="text-[26px] font-bold text-text-main">Aktivitas</h1>
        <p className="text-[13px] text-text-sec mt-1.5 font-medium">
          {format(new Date(), 'dd MMMM yyyy', { locale: id })}
        </p>
      </div>

      <div className="px-6">
        <div className="bg-palm text-white rounded-[24px] p-5 shadow-soft flex items-center justify-between">
          <div>
            <h2 className="text-[20px] font-bold">Ringkasan</h2>
            <p className="text-white/80 text-[13px] font-medium mt-1">{tasks.length} tugas • {selesai} selesai</p>
          </div>
          <div className="relative w-[60px] h-[60px] flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="30" cy="30" r="26" stroke="rgba(255,255,255,0.2)" strokeWidth="6" fill="none" />
              <circle cx="30" cy="30" r="26" stroke="#ffffff" strokeWidth="6" fill="none" strokeDasharray="163" strokeDashoffset={163 - (163 * (selesai/tasks.length))} strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-[14px] font-bold">{Math.round((selesai/tasks.length)*100)}%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 mt-8 space-y-6">
        <div>
          <h2 className="text-[18px] font-bold text-text-main mb-4">Hari Ini</h2>
          <div className="space-y-4">
            {tasks.map(task => {
              const block = blocks.find(b => b.id === task.blokId);
              return <SwipeableTaskCard key={task.id} task={task} block={block} updateTaskStatus={updateTaskStatus} />;
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function SwipeableTaskCard({ task, block, updateTaskStatus }: any) {
  const controls = useAnimation();
  const isDone = task.status === 'Selesai';
  
  const handleDragEnd = async (event: any, info: any) => {
    const threshold = 100;
    if (info.offset.x > threshold) {
      updateTaskStatus(task.id, isDone ? 'Belum Mulai' : 'Selesai');
    } else if (info.offset.x < -threshold) {
      // Demo only visual trigger for 'update'
      console.log('Update action triggered');
    }
    controls.start({ x: 0, transition: { type: 'spring', stiffness: 300, damping: 25 } });
  };

  return (
    <div className="relative rounded-[24px] overflow-hidden bg-palm shadow-soft">
      {/* Background Actions */}
      <div className="absolute inset-y-0 left-0 flex items-center pl-6 z-0">
        <span className="text-white font-bold text-[14px]">{isDone ? 'Batal Selesai' : 'Tandai Selesai'}</span>
      </div>
      <div className="absolute inset-y-0 right-0 flex items-center pr-6 z-0">
        <span className="text-white font-bold text-[14px]">Update</span>
      </div>
      
      {/* Draggable Card */}
      <motion.div
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.4}
        onDragEnd={handleDragEnd}
        animate={controls}
        whileTap={{ cursor: 'grabbing' }}
        className="relative bg-surface rounded-[24px] p-4 flex items-center gap-4 z-10 touch-pan-y"
      >
        <div className="w-[60px] h-[60px] rounded-[16px] overflow-hidden shrink-0">
          <img 
            src={task.kategori === 'PANEN' ? "https://images.unsplash.com/photo-1601055531551-789ecce21731?auto=format&fit=crop&q=80&w=150" : 
                 task.kategori === 'PEMUPUKAN' ? "https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&q=80&w=150" :
                 "https://images.unsplash.com/photo-1621508620775-520f30504d60?auto=format&fit=crop&q=80&w=150"} 
            alt={task.kategori} 
            className="w-full h-full object-cover" 
          />
        </div>
        <div className="flex-1">
          <h3 className="text-[16px] font-bold text-text-main capitalize">{task.kategori.toLowerCase()}</h3>
          <p className="text-[13px] font-medium text-text-main mt-0.5">{block?.name}</p>
          <p className="text-[12px] text-text-sec mt-1">{task.target}</p>
        </div>
        <button 
          onClick={() => updateTaskStatus(task.id, isDone ? 'Belum Mulai' : 'Selesai')}
          className="p-2 shrink-0 active:scale-90 transition-transform"
        >
          {isDone ? (
            <CheckCircle2 className="w-8 h-8 text-palm" strokeWidth={2.5} />
          ) : (
            <Circle className="w-8 h-8 text-gray-200 hover:text-palm transition-colors" strokeWidth={2} />
          )}
        </button>
      </motion.div>
    </div>
  );
}
