import React from 'react';
import { useAppContext } from '../store/AppContext';
import { Plus, TrendingUp, Briefcase } from 'lucide-react';

export function Penjualan() {
  const { sales } = useAppContext();

  const totalPendapatan = sales.reduce((acc, curr) => acc + (curr.beratBersihKg * curr.hargaPerKg), 0);
  const totalTonase = sales.reduce((acc, curr) => acc + curr.beratBersihKg, 0);

  return (
    <div className="pb-12">
      <div className="px-6 pt-12 pb-4 flex justify-between items-center">
        <h1 className="text-[26px] font-bold text-text-main">Penjualan</h1>
        <button className="w-10 h-10 bg-surface rounded-full flex items-center justify-center shadow-float border border-gray-100/50 active:scale-95 transition-transform text-text-main">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="px-6 mt-2">
        <div className="bg-surface rounded-[28px] p-8 shadow-soft flex flex-col items-center justify-center text-center">
          <p className="text-[14px] font-semibold text-text-sec mb-2">Penjualan Bulan Ini</p>
          <h2 className="text-[36px] font-bold text-text-main leading-tight mb-3">
            Rp {(totalPendapatan / 1000000).toLocaleString('id-ID', {minimumFractionDigits: 1, maximumFractionDigits: 2})} M
          </h2>
          <div className="bg-palm/10 text-palm px-4 py-1.5 rounded-full text-[14px] font-bold">
            {(totalTonase / 1000).toLocaleString('id-ID', {minimumFractionDigits: 1, maximumFractionDigits: 1})} Ton TBS
          </div>
        </div>
      </div>

      <div className="px-6 mt-8 space-y-4">
        <h2 className="text-[18px] font-bold text-text-main mb-2">Riwayat Transaksi</h2>
        {sales.map((sale) => {
          const revenue = sale.beratBersihKg * sale.hargaPerKg;
          return (
            <div key={sale.id} className="bg-surface rounded-[24px] p-4 shadow-soft flex items-center gap-4">
              <div className="w-14 h-14 bg-surface-sec rounded-[18px] flex items-center justify-center shrink-0">
                <Briefcase className="w-6 h-6 text-text-sec" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-[16px] font-bold text-text-main truncate">{sale.buyer}</h3>
                <p className="text-[13px] font-medium text-text-sec mt-0.5">
                  {sale.beratBersihKg.toLocaleString('id-ID')} Kg • Rp{sale.hargaPerKg}
                </p>
                <p className="text-[15px] font-bold text-palm mt-1">Rp {revenue.toLocaleString('id-ID')}</p>
              </div>
              <div className="flex flex-col items-end shrink-0 gap-2">
                <div className="px-3 py-1 bg-gray-100 text-gray-500 rounded-full text-[10px] font-bold tracking-wider">
                  PAID
                </div>
                <span className="text-[11px] font-medium text-text-sec">
                  {new Date(sale.tanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
