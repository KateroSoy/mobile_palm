import React from 'react';
import { Settings, Bell, Lock, HelpCircle, Info, LogOut, ChevronRight } from 'lucide-react';

export function Profil() {
  return (
    <div className="pb-8">
      <div className="px-6 pt-12 pb-8 bg-surface rounded-b-[34px] shadow-soft">
        <div className="flex flex-col items-center text-center">
          <div className="w-24 h-24 rounded-full bg-palm/10 flex items-center justify-center mb-4 overflow-hidden border-4 border-white shadow-soft">
            <img 
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150&h=150" 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
          </div>
          <h1 className="text-[22px] font-bold text-text-main">Jack Ma</h1>
          <p className="text-[14px] text-text-sec mt-1">Owner • PT Palma Nusantara</p>
        </div>
      </div>

      <div className="px-6 mt-8 space-y-3">
        <MenuRow icon={Settings} label="Pilih Kebun" />
        <MenuRow icon={Bell} label="Notifikasi" badge="3" />
        <MenuRow icon={Lock} label="Keamanan" />
        <MenuRow icon={HelpCircle} label="Bantuan" />
        <MenuRow icon={Info} label="Tentang PALM" />
        
        <div className="pt-4">
          <MenuRow icon={LogOut} label="Keluar" isDestructive />
        </div>
      </div>
    </div>
  );
}

function MenuRow({ icon: Icon, label, badge, isDestructive }: any) {
  return (
    <button className={`w-full bg-surface p-4 rounded-[20px] flex items-center justify-between shadow-soft active:scale-95 transition-transform ${isDestructive ? 'text-red-500' : 'text-text-main'}`}>
      <div className="flex items-center gap-4">
        <div className={`p-2.5 rounded-full ${isDestructive ? 'bg-red-50' : 'bg-surface-sec'}`}>
          <Icon className="w-5 h-5" />
        </div>
        <span className="font-semibold text-[15px]">{label}</span>
      </div>
      <div className="flex items-center gap-3">
        {badge && (
          <span className="bg-palm text-white text-xs font-bold px-2 py-0.5 rounded-full">{badge}</span>
        )}
        <ChevronRight className={`w-5 h-5 ${isDestructive ? 'text-red-300' : 'text-gray-300'}`} />
      </div>
    </button>
  );
}
